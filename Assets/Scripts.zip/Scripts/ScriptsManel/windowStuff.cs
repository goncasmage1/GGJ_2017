﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class windowStuff : MonoBehaviour {


	// Use this for initialization
	void Start () {
		Screen.SetResolution (768, 1024, false, 0);
	}
	
	// Update is called once per frame
	void Update () {

	}
}
